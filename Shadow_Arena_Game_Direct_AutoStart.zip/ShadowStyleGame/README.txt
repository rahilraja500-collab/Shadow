SHADOW ARENA — 3D FIGHTING PROTOTYPE

This build embeds both supplied FBX characters inside the game so it does not need a file picker.
Open index.html in a browser and use landscape mode.

Controls:
Left/Right = move, Up = jump
J = punch, K = kick, L = critical
Touch controls are shown on screen.

The arena is procedural 3D with ruins, columns, trees, mountains, fog, shadows and lighting.
The supplied characters are unrigged, so this prototype uses whole-character movement/attack effects rather than skeletal combat animation.
