Shadow Arena Android project

This project wraps the supplied ShadowStyleGame HTML/FBX game in an Android WebView.
GitHub Actions can build it without a PC using Android Gradle Plugin.

The game HTML is in app/src/main/assets/game/index.html and the FBX files are in app/src/main/assets/game/assets/.
