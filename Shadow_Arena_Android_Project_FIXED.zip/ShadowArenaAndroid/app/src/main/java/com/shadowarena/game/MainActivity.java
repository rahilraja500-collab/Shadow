package com.shadowarena.game;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().getDecorView().setSystemUiVisibility(
      View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
      View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
      View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    WebView w = new WebView(this);
    w.setWebViewClient(new WebViewClient());
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
    s.setJavaScriptCanOpenWindowsAutomatically(true);
    if (android.os.Build.VERSION.SDK_INT >= 21) {
      s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
    }
    if (android.os.Build.VERSION.SDK_INT >= 16) {
      w.getSettings().setAllowUniversalAccessFromFileURLs(true);
      w.getSettings().setAllowFileAccessFromFileURLs(true);
    }
    w.setBackgroundColor(0x00000000);
    w.loadUrl("file:///android_asset/game/index.html");
    setContentView(w);
  }
  @Override public void onWindowFocusChanged(boolean h) { super.onWindowFocusChanged(h); if(h) getWindow().getDecorView().setSystemUiVisibility(5894); }
}
